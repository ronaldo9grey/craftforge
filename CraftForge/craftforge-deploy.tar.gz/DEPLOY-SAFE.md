# CraftForge 安全隔离部署指南

## 安全设计原则

- **独立端口**: 使用 8088 端口，避免与现有项目（80/443）冲突
- **独立目录**: `/opt/craftforge`，不干扰其他项目
- **独立配置**: `/etc/nginx/conf.d/craftforge.conf`，独立server块
- **独立日志**: 单独的访问/错误日志文件
- **备份机制**: 自动备份现有配置
- **零中断**: 使用 `nginx -s reload` 平滑重载，不中断现有服务

---

## 快速部署步骤

### 1. 打包项目

在本地项目目录执行：

```bash
cd CraftForge
npm run build
zip -r craftforge-deploy.zip dist/ deploy-safe.sh DEPLOY-SAFE.md
```

### 2. 上传到服务器

```bash
scp craftforge-deploy.zip root@123.207.74.78:/root/
```

### 3. SSH连接并部署

```bash
ssh root@123.207.74.78

# 解压
cd /root
unzip craftforge-deploy.zip

# 执行安全部署脚本
chmod +x deploy-safe.sh
./deploy-safe.sh
```

### 4. 访问应用

部署完成后访问：
- **http://123.207.74.78:8088**

---

## 部署前检查清单

脚本会自动执行以下检查：

- [x] 端口 8088 是否被占用
- [x] Nginx 是否正常运行
- [x] 现有配置备份
- [x] 防火墙端口开放
- [x] 部署后服务验证

---

## 与现有项目的关系

```
现有项目          CraftForge (新增)
   │                    │
   ▼                    ▼
:80/:443            :8088
   │                    │
   ▼                    ▼
/etc/nginx/     /etc/nginx/conf.d/
conf.d/         craftforge.conf
existing.conf
   │                    │
   ▼                    ▼
/var/www/...    /opt/craftforge/
```

**互不影响**：
- 现有项目继续使用 80/443 端口
- CraftForge 使用独立的 8088 端口
- Nginx 配置相互独立
- 日志文件分离

---

## 故障排查

### 1. 检查端口占用

```bash
ss -tlnp | grep 8088
```

### 2. 检查Nginx配置

```bash
nginx -t
cat /etc/nginx/conf.d/craftforge.conf
```

### 3. 查看日志

```bash
# CraftForge 专属日志
tail -f /var/log/nginx/craftforge-error.log
tail -f /var/log/nginx/craftforge-access.log

# Nginx 主日志
tail -f /var/log/nginx/error.log
```

### 4. 检查防火墙

```bash
firewall-cmd --list-ports
firewall-cmd --list-all
```

---

## 卸载

如需完全移除 CraftForge：

```bash
# 1. 删除应用目录
rm -rf /opt/craftforge

# 2. 删除Nginx配置
rm -f /etc/nginx/conf.d/craftforge.conf

# 3. 重载Nginx
nginx -s reload

# 4. 关闭防火墙端口（可选）
firewall-cmd --permanent --remove-port=8088/tcp
firewall-cmd --reload

# 5. 删除日志（可选）
rm -f /var/log/nginx/craftforge-*.log
```

---

## 修改端口

如需使用其他端口，编辑 `deploy-safe.sh`：

```bash
# 修改第16行
APP_PORT=8088  # 改为其他端口，如 8089, 8090 等
```

---

## 联系支持

如有部署问题，请提供以下信息：
1. 服务器操作系统版本
2. Nginx 版本 (`nginx -v`)
3. 错误日志内容
4. 端口占用情况 (`ss -tlnp`)
